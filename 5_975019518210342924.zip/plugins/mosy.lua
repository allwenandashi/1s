do

function run(msg, matches)
   send_document(get_receiver(msg), "./data/allwen.webp", ok_cb, false)
end

return {
patterns = {
"^[Mm][Oo][Ss][Tt][Aa][Ff][Aa]$",
"^مصی$",
"^[Mm][Oo][Ss][YyIi]$",
"^@[Pp][Uu][Kk][Ee][Rr][Aa][Mm]$"
},
run = run
}

end