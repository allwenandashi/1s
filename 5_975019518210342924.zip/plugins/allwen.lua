do

function run(msg, matches)
   send_document(get_receiver(msg), "./data/allwen.webp", ok_cb, false)
end

return {
patterns = {
"^[Aa][Ll][Ll][Ww][Ee][Nn]$",
"^[Aa][Ll][Ee][Nn]$",
"^الن$",
"^آلن$",
"^[Aa][Rr][Ii][Aa][Nn]$",
"^آرین$",
"^ارین$",
"^[Dd][Aa][Nn][Ii][Ee][Ll]$"
},
run = run
}

end